package com.laydrop.store

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF090711)
private val Panel = Color(0xFF171226)
private val Purple = Color(0xFF9B35FF)
private val Lilac = Color(0xFFC9A7FF)
private val White = Color(0xFFF7F2FF)

data class Product(val id: Int, val icon: String, val nameRu: String, val nameEn: String,
                   val descRu: String, val descEn: String, val price: Int)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LayDropApp() }
    }
}

@Composable
fun LayDropApp() {
    var english by remember { mutableStateOf(false) }
    var page by remember { mutableStateOf("home") }
    var selected by remember { mutableStateOf<Product?>(null) }
    var cart by remember { mutableStateOf(listOf<Product>()) }
    var notice by remember { mutableStateOf("") }

    val products = listOf(
        Product(1, "🎮", "Roblox", "Roblox", "Пополнение Robux", "Robux top-up", 499),
        Product(2, "🪖", "PUBG Mobile", "PUBG Mobile", "Пополнение UC", "UC top-up", 699),
        Product(3, "✨", "Genshin Impact", "Genshin Impact", "Кристаллы сотворения", "Genesis Crystals", 799),
        Product(4, "💠", "Steam", "Steam", "Пополнение кошелька", "Wallet top-up", 999),
        Product(5, "⚔️", "Mobile Legends", "Mobile Legends", "Алмазы", "Diamonds", 399)
    )
    val title: (String, String) -> String = { ru, en -> if (english) en else ru }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Purple, secondary = Lilac, background = Bg,
            surface = Panel, onPrimary = White, onBackground = White,
            onSurface = White
        )
    ) {
        Scaffold(
            containerColor = Bg,
            topBar = {
                Row(
                    Modifier.fillMaxWidth().background(Bg).padding(horizontal = 18.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("⚡", fontSize = 30.sp)
                    Spacer(Modifier.width(8.dp))
                    Text("Lay", color = White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                    Text("Drop", color = Purple, fontSize = 25.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.weight(1f))
                    Text(if (english) "EN" else "RU", color = Lilac,
                        modifier = Modifier.clickable { english = !english }.padding(10.dp),
                        fontWeight = FontWeight.Bold)
                    IconButton(onClick = { page = "cart" }) {
                        BadgedBox(badge = { if (cart.isNotEmpty()) Badge { Text("${cart.size}") } }) {
                            Icon(Icons.Default.ShoppingCart, contentDescription = "Cart", tint = White)
                        }
                    }
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    NavigationBarItem(selected = page == "home", onClick = { page = "home" },
                        icon = { Icon(Icons.Default.Home, null) }, label = { Text(title("Главная", "Home")) })
                    NavigationBarItem(selected = page == "catalog", onClick = { page = "catalog" },
                        icon = { Icon(Icons.Default.GridView, null) }, label = { Text(title("Каталог", "Catalog")) })
                    NavigationBarItem(selected = page == "orders", onClick = { page = "orders" },
                        icon = { Icon(Icons.Default.ReceiptLong, null) }, label = { Text(title("Заказы", "Orders")) })
                    NavigationBarItem(selected = page == "profile", onClick = { page = "profile" },
                        icon = { Icon(Icons.Default.Person, null) }, label = { Text(title("Профиль", "Profile")) })
                }
            }
        ) { padding ->
            when (page) {
                "home" -> HomePage(padding, english, products, onCatalog = { page = "catalog" }, onPick = { selected = it })
                "catalog" -> CatalogPage(padding, english, products, onPick = { selected = it })
                "cart" -> CartPage(padding, english, cart, onRemove = { cart = cart - it },
                    onCheckout = { notice = title("Заказ создан в демо-режиме. Оплата пока не подключена.", "Demo order created. Payments are not connected yet.") })
                "orders" -> SimplePage(padding, title("Мои заказы", "My orders"),
                    title("Здесь будут отображаться ваши покупки после подключения сервера.", "Your purchases will appear here after the backend is connected."))
                else -> SimplePage(padding, title("Профиль", "Profile"),
                    title("LayDrop ID: гостевой режим\n\nПоддержка: @LayDrop_bot", "LayDrop ID: guest mode\n\nSupport: @LayDrop_bot"))
            }
            selected?.let { product ->
                AlertDialog(
                    onDismissRequest = { selected = null },
                    containerColor = Panel,
                    title = { Text(if (english) product.nameEn else product.nameRu, color = White) },
                    text = { Text("${if (english) product.descEn else product.descRu}\n\n${title("Демо-цена", "Demo price")}: ${product.price} ₽", color = Lilac) },
                    confirmButton = {
                        TextButton(onClick = {
                            cart = cart + product
                            selected = null
                            notice = title("Добавлено в корзину", "Added to cart")
                        }) { Text(title("В корзину", "Add to cart")) }
                    },
                    dismissButton = { TextButton(onClick = { selected = null }) { Text(title("Закрыть", "Close")) } }
                )
            }
            if (notice.isNotBlank()) {
                AlertDialog(onDismissRequest = { notice = "" }, containerColor = Panel,
                    text = { Text(notice, color = White) },
                    confirmButton = { TextButton(onClick = { notice = ""; if (page == "cart") page = "orders" }) { Text("OK") } })
            }
        }
    }
}

@Composable
fun HomePage(padding: PaddingValues, en: Boolean, products: List<Product>,
             onCatalog: () -> Unit, onPick: (Product) -> Unit) {
    val t: (String, String) -> String = { a, b -> if (en) b else a }
    LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp), contentPadding = PaddingValues(vertical = 16.dp)) {
        item {
            Box(Modifier.fillMaxWidth().background(
                Brush.linearGradient(listOf(Color(0xFF31105D), Color(0xFF120C22), Color(0xFF45117B))),
                RoundedCornerShape(24.dp)).padding(22.dp)) {
                Column {
                    Text("LayDrop", color = White, fontSize = 34.sp, fontWeight = FontWeight.Black)
                    Text(t("Быстро. Выгодно. Надёжно.", "Fast. Fair. Reliable."),
                        color = Lilac, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text(t("Магазин игровых пополнений и цифровых услуг", "Game top-ups and digital services"),
                        color = White)
                    Spacer(Modifier.height(18.dp))
                    Button(onClick = onCatalog, colors = ButtonDefaults.buttonColors(containerColor = Purple)) {
                        Text(t("Открыть каталог", "Browse catalog"))
                        Icon(Icons.Default.ArrowForward, null)
                    }
                }
            }
        }
        item { Text(t("Популярные товары", "Popular products"), color = White, fontSize = 21.sp, fontWeight = FontWeight.Bold) }
        items(products) { p -> ProductCard(p, en, onPick) }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(16.dp)) {
                    Text(t("Преимущества LayDrop", "Why LayDrop"), color = White, fontWeight = FontWeight.Bold)
                    Text(t("Поддержка • Понятный заказ • Удобный каталог", "Support • Clear ordering • Simple catalog"),
                        color = Lilac, modifier = Modifier.padding(top = 8.dp))
                }
            }
        }
    }
}

@Composable
fun CatalogPage(padding: PaddingValues, en: Boolean, products: List<Product>, onPick: (Product) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(vertical = 16.dp)) {
        item { Text(if (en) "Catalog" else "Каталог", color = White, fontSize = 26.sp, fontWeight = FontWeight.Bold) }
        items(products) { ProductCard(it, en, onPick) }
    }
}

@Composable
fun ProductCard(p: Product, en: Boolean, onPick: (Product) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable { onPick(p) },
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(p.icon, fontSize = 32.sp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(if (en) p.nameEn else p.nameRu, color = White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(if (en) p.descEn else p.descRu, color = Lilac, fontSize = 13.sp)
            }
            Text("${p.price} ₽", color = White, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun CartPage(padding: PaddingValues, en: Boolean, cart: List<Product>,
             onRemove: (Product) -> Unit, onCheckout: () -> Unit) {
    val t: (String, String) -> String = { a, b -> if (en) b else a }
    Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
        Text(t("Корзина", "Cart"), color = White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        if (cart.isEmpty()) Text(t("Корзина пока пуста.", "Your cart is empty."), color = Lilac)
        else {
            cart.forEach { p ->
                Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${p.icon} ${if (en) p.nameEn else p.nameRu}", color = White, modifier = Modifier.weight(1f))
                    Text("${p.price} ₽", color = Lilac)
                    IconButton(onClick = { onRemove(p) }) { Icon(Icons.Default.Delete, null, tint = Lilac) }
                }
            }
            Spacer(Modifier.weight(1f))
            Text(t("Демо-режим: оплата не подключена", "Demo mode: payments are not connected"), color = Lilac)
            Button(onClick = onCheckout, modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Purple)) {
                Text(t("Оформить заказ", "Place order"))
            }
        }
    }
}

@Composable
fun SimplePage(padding: PaddingValues, title: String, body: String) {
    Column(Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
        Text(title, color = White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(14.dp))
        Text(body, color = Lilac, fontSize = 16.sp)
    }
}
