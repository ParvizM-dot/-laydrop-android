# LayDrop Android app — starter project

A native Android app prototype built with Kotlin and Jetpack Compose.

## Included
- Dark premium purple LayDrop visual style
- Russian / English language toggle
- Home screen and product catalogue
- Sample game top-up products
- Local in-memory cart
- Demo order flow
- Orders and profile placeholder screens

## Important limitations
This is a **frontend prototype**, not a production store. Prices are placeholders.
Payments, server-side order storage, user authentication, supplier fulfillment,
refunds and Telegram bot synchronization are not connected. Do not accept real
payments or promise delivery until a secure backend and authorized supplier API
are implemented and tested.

## Build APK
1. Open this folder in Android Studio (on a computer).
2. Let Gradle sync and install Android SDK 35 if prompted.
3. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Android Studio creates the APK under `app/build/outputs/apk/debug/`.

You can also build from a computer with Android SDK and JDK 17:
`gradle assembleDebug`

Package: `com.laydrop.store`
Minimum Android: 7.0 (API 24)


## Build APK from an Android phone (GitHub Actions)

This project includes `.github/workflows/build-apk.yml`.
After the project files are uploaded to a GitHub repository:
1. Open the repository in a browser and select the **Actions** tab.
2. Select **Build LayDrop APK**.
3. Tap **Run workflow** (or wait for the first push build).
4. When the run finishes successfully, open the run and download the
   `LayDrop-debug-APK` artifact. GitHub may ask you to sign in.
5. Extract the downloaded artifact ZIP; it contains `app-debug.apk`.

GitHub Actions has usage allowances and limits. Check your account's billing
page before enabling any paid usage. Public repositories have free standard
runner usage according to GitHub's current policy.

This is a debug/test APK, not a Play Store release. Do not distribute it as a
production app. The app is still a UI prototype; payments and live fulfillment
are not implemented.
